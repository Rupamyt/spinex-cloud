// Click animation effect
document.addEventListener("click", function (e) {
  let effect = document.createElement("div");
  effect.className = "click-effect";
  effect.style.left = e.pageX + "px";
  effect.style.top = e.pageY + "px";
  document.body.appendChild(effect);
  setTimeout(() => effect.remove(), 400);
});

// Mock Payment Function
function payNow(plan) {
  alert(`Redirecting to payment for ${plan.toUpperCase()} plan`);
  // You can integrate Stripe or PayPal here
  // Example: window.location.href = "https://checkout.stripe.com/pay/YOUR_PAYMENT_LINK"
}
